
export default function Home() {
  return (
    <main style={{ fontFamily: 'Arial, sans-serif', padding: '40px', maxWidth: '900px', margin: 'auto' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1>Immunization: Protect Your Child’s Future</h1>
          <p style={{ color: '#555' }}>ImmunizeFuture.org</p>
        </div>
        <select>
          <option>English</option>
          <option>Español</option>
        </select>
      </header>

      <section style={{ marginTop: '40px' }}>
        <h2>Protecting Families Through Immunization</h2>
        <p>
          A nonprofit public-service resource helping parents and communities access trusted
          vaccine information and nearby immunization services.
        </p>
      </section>

      <section style={{ marginTop: '40px' }}>
        <h2>Find Immunization Locations Near You</h2>
        <input placeholder="Enter ZIP code" />
        <button style={{ marginLeft: '10px' }}>Search</button>
      </section>

      <section style={{ marginTop: '40px' }}>
        <h2>For Parents</h2>
        <p>
          Keeping your child up to date on recommended immunizations helps protect them during
          their most vulnerable years.
        </p>
      </section>

      <section style={{ marginTop: '40px' }}>
        <h2>Contact Us / Contáctenos</h2>
        <p>📞 813-731-9221</p>
        <p>✉️ aespinoza0829@icloud.com</p>
      </section>

      <footer style={{ marginTop: '60px', fontSize: '12px', color: '#666' }}>
        This nonprofit public-service website provides educational information and does not replace
        professional medical advice.
      </footer>
    </main>
  );
}
